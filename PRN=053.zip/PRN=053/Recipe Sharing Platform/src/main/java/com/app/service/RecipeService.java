// RecipeService.java
package com.app.service;

import com.app.entities.Recipe;

import java.util.List;

public interface RecipeService {

    Recipe getRecipeById(Long recipeId);

    Recipe createRecipe(Recipe recipe);

    boolean updateRecipe(Long recipeId, Recipe updatedRecipe);

    boolean deleteRecipe(Long recipeId);

    List<Recipe> getAllRecipes();
}
