// MealType.java
package com.app.entities;

public enum MealType {
    BREAKFAST,
    LUNCH,
    DINNER,
    SNACK
    
}
