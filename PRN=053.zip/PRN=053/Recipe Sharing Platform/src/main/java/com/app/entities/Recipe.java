//Recipe.java
package com.app.entities;

import lombok.*;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Recipe extends BaseEntity {

 @NotBlank(message = "Title cannot be blank")
 @Length(max = 255, message = "Title cannot exceed 255 characters")
 private String title;

 @NotBlank(message = "Description cannot be blank")
 @Length(max = 1000, message = "Description cannot exceed 1000 characters")
 private String description;

 @NotBlank(message = "Ingredients cannot be blank")
 @Length(max = 2000, message = "Ingredients cannot exceed 2000 characters")
 private String ingredients;

 @NotBlank(message = "Instructions cannot be blank")
 @Length(max = 2000, message = "Instructions cannot exceed 2000 characters")
 private String instructions;

 @NotBlank(message = "Difficulty level cannot be blank")
 @Length(max = 50, message = "Difficulty level cannot exceed 50 characters")
 private String difficultyLevel;

 @NotBlank(message = "Cuisine type cannot be blank")
 @Length(max = 50, message = "Cuisine type cannot exceed 50 characters")
 private String cuisineType;

 @NotNull(message = "Author ID cannot be null")
 private Long authorId;

 @Enumerated(EnumType.STRING)
 @NotNull(message = "Meal type cannot be null")
 private MealType mealType;

 private LocalDateTime creationDate;
}
