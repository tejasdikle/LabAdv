// RecipeServiceImpl.java
package com.app.service;

import com.app.entities.Recipe;
import com.app.repository.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RecipeServiceImpl implements RecipeService {

    @Autowired
    private RecipeRepository recipeRepository;

    @Override
    public Recipe getRecipeById(Long recipeId) {
        Optional<Recipe> optionalRecipe = recipeRepository.findById(recipeId);
        return optionalRecipe.orElse(null);
    }

    @Override
    public Recipe createRecipe(Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    @Override
    public boolean updateRecipe(Long recipeId, Recipe updatedRecipe) {
        if (recipeRepository.existsById(recipeId)) {
            updatedRecipe.setId(recipeId);
            recipeRepository.save(updatedRecipe);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteRecipe(Long recipeId) {
        if (recipeRepository.existsById(recipeId)) {
            recipeRepository.deleteById(recipeId);
            return true;
        }
        return false;
    }

    @Override
    public List<Recipe> getAllRecipes() {
        return recipeRepository.findAll();
    }
}
