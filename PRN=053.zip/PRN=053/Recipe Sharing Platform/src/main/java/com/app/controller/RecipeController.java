// RecipeController.java
package com.app.controller;

import com.app.entities.Recipe;
import com.app.service.RecipeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/recipes")
public class RecipeController {

    @Autowired
    private RecipeService recipeService;

    @GetMapping("/{recipeId}")
    public ResponseEntity<?> getRecipeById(@PathVariable Long recipeId) {
        try {
            Recipe recipe = recipeService.getRecipeById(recipeId);
            if (recipe != null) {
                return new ResponseEntity<>(recipe, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Recipe not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Error retrieving recipe", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping
    public ResponseEntity<?> createRecipe(@Valid @RequestBody Recipe recipe) {
        try {
            Recipe createdRecipe = recipeService.createRecipe(recipe);
            return new ResponseEntity<>("Recipe created with ID: " + createdRecipe.getId(), HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Error creating recipe", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{recipeId}")
    public ResponseEntity<?> updateRecipe(@PathVariable Long recipeId, @RequestBody Recipe updatedRecipe) {
        try {
            boolean success = recipeService.updateRecipe(recipeId, updatedRecipe);
            if (success) {
                return new ResponseEntity<>("Recipe updated successfully", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Recipe not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Error updating recipe", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{recipeId}")
    public ResponseEntity<?> deleteRecipe(@PathVariable Long recipeId) {
        try {
            boolean success = recipeService.deleteRecipe(recipeId);
            if (success) {
                return new ResponseEntity<>("Recipe deleted successfully", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Recipe not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Error deleting recipe", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
