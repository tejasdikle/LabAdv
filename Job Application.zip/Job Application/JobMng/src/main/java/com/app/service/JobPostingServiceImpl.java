package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.JobPostingRepository;
import com.app.entities.JobPosting;

import java.util.List;

@Service
public class JobPostingServiceImpl implements JobPostingService {

    @Autowired
    private JobPostingRepository jobPostingRepository;

    @Override
    public List<JobPosting> getAllJobPostings() {
        return jobPostingRepository.findAll();
    }

    @Override
    public JobPosting getJobPostingById(Long jobId) {
        return jobPostingRepository.findById(jobId).orElse(null);
    }

    @Override
    public JobPosting createJobPosting(JobPosting jobPosting) {
        return jobPostingRepository.save(jobPosting);
    }

    @Override
    public JobPosting updateJobPosting(Long jobId, JobPosting updatedJobPosting) {
        JobPosting existingJobPosting = jobPostingRepository.findById(jobId).orElse(null);

        if (existingJobPosting != null) {
            // Update fields as needed
            existingJobPosting.setJobTitle(updatedJobPosting.getJobTitle());
            existingJobPosting.setCompanyName(updatedJobPosting.getCompanyName());
            existingJobPosting.setLocation(updatedJobPosting.getLocation());
            existingJobPosting.setDescription(updatedJobPosting.getDescription());
            existingJobPosting.setRequirements(updatedJobPosting.getRequirements());
            existingJobPosting.setSalary(updatedJobPosting.getSalary());

            return jobPostingRepository.save(existingJobPosting);
        }

        return null;
    }

    @Override
    public void deleteJobPosting(Long jobId) {
        jobPostingRepository.deleteById(jobId);
    }
}
