package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.app.entities.JobPosting;
import com.app.service.JobPostingService;

import java.util.List;

@RestController
@RequestMapping("/jobPostings")
public class JobPostingController {

    @Autowired
    private JobPostingService jobPostingService;

    @GetMapping
    public List<JobPosting> getAllJobPostings() {
        return jobPostingService.getAllJobPostings();
    }

    @GetMapping("/{jobId}")
    public JobPosting getJobPostingById(@PathVariable Long jobId) {
        return jobPostingService.getJobPostingById(jobId);
    }

    @PostMapping
    public JobPosting createJobPosting(@RequestBody JobPosting jobPosting) {
        return jobPostingService.createJobPosting(jobPosting);
    }

    @PutMapping("/{jobId}")
    public JobPosting updateJobPosting(@PathVariable Long jobId, @RequestBody JobPosting updatedJobPosting) {
        return jobPostingService.updateJobPosting(jobId, updatedJobPosting);
    }

    @DeleteMapping("/{jobId}")
    public void deleteJobPosting(@PathVariable Long jobId) {
        jobPostingService.deleteJobPosting(jobId);
    }
}


