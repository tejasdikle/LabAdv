package com.app.service;

import java.util.List;

import com.app.entities.JobPosting;

public interface JobPostingService {
    List<JobPosting> getAllJobPostings();
    JobPosting getJobPostingById(Long jobId);
    JobPosting createJobPosting(JobPosting jobPosting);
    JobPosting updateJobPosting(Long jobId, JobPosting updatedJobPosting);
    void deleteJobPosting(Long jobId);
}