//Employee.java
package com.app.entities;

import lombok.*;
import org.hibernate.validator.constraints.Length;
import javax.persistence.*;
import javax.validation.constraints.*;




@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Employee extends BaseEntity {

 @NotBlank(message = "Name cannot be blank")
 @Length(max = 50)
 private String name;

 @NotBlank(message = "Cannot be blank")
 @Length(max = 50, message = "Should not be uniqe")
 private String email;

 @NotBlank(message = "cannot be blank")
 @Length( message = "Cannot be blank")
 private String joining_date;

 @Enumerated(EnumType.STRING)
 @NotNull(message = "Cannot be null")
 private GenderType gender;


}
