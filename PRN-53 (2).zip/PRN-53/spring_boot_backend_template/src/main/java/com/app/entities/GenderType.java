// GenderType.java
package com.app.entities;

public enum GenderType {
    MALE,FEMALE
    
}
