// EmployeeService.java
package com.app.service;

import com.app.entities.Employee;


import java.util.List;

public interface EmployeeService {

    Employee getEmployeeById(Long employeeId);

    Employee addEmployee(Employee employee);

    boolean updateEmployee(Long employeeId, Employee updatedEmployee);

    boolean deleteEmployee(Long employeeId);

    List<Employee> getAllEmployee();
}
